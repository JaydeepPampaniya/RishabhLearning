package com.PhoneX.Backend.Service;


import com.PhoneX.Backend.DTO.LoginDTO;
import com.PhoneX.Backend.DTO.RegistrationCustomerDTO;
import com.PhoneX.Backend.config.PasswordEncoderConfig;
import com.PhoneX.Backend.constants.MessageConstants;
import com.PhoneX.Backend.entity.Customer;
import com.PhoneX.Backend.entity.User;
import com.PhoneX.Backend.globalException.BadRequestException;
import com.PhoneX.Backend.globalException.ConflictException;
import com.PhoneX.Backend.globalException.NotFoundException;
import com.PhoneX.Backend.globalException.UnauthorizedException;
import com.PhoneX.Backend.repository.CartRepository;
import com.PhoneX.Backend.repository.CustomerRepository;
import com.PhoneX.Backend.repository.UserRepository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoderConfig passwordEncoderConfig;
    private final CustomerRepository customerRepository;
    private final JwtService jwtService;
    private final CartRepository cartRepository;

    @Autowired
    public UserService(UserRepository userRepository , PasswordEncoderConfig passwordEncoderConfig, CustomerRepository customerRepository, JwtService jwtService, CartRepository cartRepository){
        this.userRepository=userRepository;
        this.passwordEncoderConfig=passwordEncoderConfig;
        this.customerRepository=customerRepository;
        this.jwtService=jwtService;
        this.cartRepository=cartRepository;
    }

    @Transactional
    public String registerForCustomer(RegistrationCustomerDTO registrationCustomerDTO) {
        if(userRepository.existsByEmail(registrationCustomerDTO.getEmail())){
            throw new ConflictException(MessageConstants.EMAIL_ALREADY_EXISTS);
        }
        if(customerRepository.existsByUsername(registrationCustomerDTO.getUsername())){
            throw new ConflictException(MessageConstants.USERNAME_ALREADY_EXISTS);
        }else if(customerRepository.existsByContactNo(registrationCustomerDTO.getContactNo())){
            throw new ConflictException(MessageConstants.CONTACT_ALREADY_EXISTS);
        }

        User user = new User();
        user.setEmail(registrationCustomerDTO.getEmail());
        user.setRole(User.Role.valueOf(registrationCustomerDTO.getRole()));
        user.setPassword(passwordEncoderConfig.passwordEncoder().encode(registrationCustomerDTO.getPassword()));
        LocalDateTime localDateTime= LocalDateTime.now();
        user.setCreatedTime(localDateTime);
        userRepository.save(user);

        Customer customer=new Customer();
        customer.setUsername(registrationCustomerDTO.getUsername());
        customer.setAge(registrationCustomerDTO.getAge());
        customer.setAddress(registrationCustomerDTO.getAddress());
        customer.setGender(registrationCustomerDTO.getGender());
        customer.setContactNo(registrationCustomerDTO.getContactNo());
        customer.setUser(user);
        customerRepository.save(customer);

        return "Registered Successfully";
    }

    @Transactional
    public Map<String, Object> login(LoginDTO loginDTO) {
        Optional<User> userOptional = userRepository.findByEmail(loginDTO.getEmail());
        Map<String, Object> response = new HashMap<>();

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (passwordEncoderConfig.passwordEncoder().matches(loginDTO.getPassword(), user.getPassword())) {
                if (user.getRole().name().equals(User.Role.ADMIN.name())) {
                    response.put("token", jwtService.generateToken(user.getAdmin().getAdminname(), User.Role.ADMIN.name(), user.getEmail()));
                } else if (user.getRole().name().equals(User.Role.CUSTOMER.name())) {
                    response.put("gender", user.getCustomer().getGender());
                    response.put("token", jwtService.generateToken(user.getCustomer().getUsername(), User.Role.CUSTOMER.name(), user.getEmail()));
                }
                response.put("userId",user.getId());
                response.put("message", "Login successfully");
                return response;
            } else {
                throw new ConflictException(MessageConstants.INCORRECT_PASSWORD);
            }
        } else {
            throw new UnauthorizedException(MessageConstants.INVALID_CREDENTIALS);
        }
    }


    @Transactional
    public String changePassword(Long id, String oldPassword, String newPassword,User.Role role) {
        User user = userRepository.findById(id).orElse(new User());
        if (user.getRole() != role) {
            throw new UnauthorizedException("You do not have permission to access this resource.");
        }else if(!passwordEncoderConfig.passwordEncoder().matches(oldPassword,user.getPassword())){
            throw new BadRequestException("Old password is incorrect");
        } else if (passwordEncoderConfig.passwordEncoder().matches(newPassword,user.getPassword())) {
            throw new BadRequestException("Old password and new password cannot be same");
        } else{
            user.setPassword(passwordEncoderConfig.passwordEncoder().encode(newPassword));
            userRepository.save(user);
            return "Password Changed Successfully";
        }
    }

    public Page<Customer> getAllUser(Pageable pageable) {
        return customerRepository.findAll(pageable);
    }

    @Transactional
    public String deleteUser(Long id) {
        Optional<User> user = userRepository.findById(id);
        if(user.isPresent()){
            cartRepository.deleteByUserId(id);
            customerRepository.deleteByUserId(id);
            userRepository.deleteById(id);
            return "User Deleted.";
        }else{
            throw new UnauthorizedException(MessageConstants.USER_NOT_FOUND);
        }
    }

    @Transactional
    public String deleteCustomer(Long id) {
        Customer customer = customerRepository.findById(id).orElseThrow(()->new NotFoundException(MessageConstants.USER_NOT_FOUND));
        customerRepository.deleteById(customer.getId());
        return "Customer Deleted.";
    }
}
