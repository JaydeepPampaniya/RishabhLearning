package com.PhoneX.Backend.Service;


import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import jakarta.transaction.Transactional;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

@Service
public class JwtService {
    private static final String SECRET = "TmV3U2VjcmV0S2V5Rm9ySldUU2lnbmluZ1B1cnBvc2VzMTIzNDU2Nzg=\r\n";

    private final String secretKey;
    private static final int EXPIRATION_TIME = 1000 * 60 * 30;

    public JwtService(){
        secretKey = SECRET;
    }

    public String generateToken(String username, String role,String email){
        Map<String, Object> claims = new HashMap<>();
        claims.put("roles", List.of("ROLE_" + role));  // Store as List<String>
        claims.put("email",email);
        return Jwts.builder()
                .claims(claims)
                .subject(username)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(getKey())
                .compact(); //build jwt with compact string
    }


    private SecretKey getKey() {
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    public String extractUserName(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    /*

    Applies claimResolver Function:
    Uses a Function<Claims, T> (a functional interface from Java 8) to specify which claim to extract.
    claimResolver is passed as an argument, which allows the method to be flexible and reusable.
    The function is then applied to the Claims object to extract the desired claim.

     */

    private <T> T extractClaim(String token, Function<Claims, T> claimResolver) { //Java Generics (<T>) to allow different types of claims to be extracted (e.g., String for username, List<String> for roles, Date for expiration, etc.).
        final Claims claims = extractAllClaims(token);
        return claimResolver.apply(claims);
    }

    public List<String> extractRoles(String token) {
        return extractClaim(token, claims -> claims.get("roles", List.class));
    }

    private Claims extractAllClaims(String token) {
        return Jwts.parser()
                .verifyWith(getKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public boolean validateToken(String token, UserDetails userDetails) {
        try {
            final String userName = extractUserName(token);
            return (userName.equals(userDetails.getUsername()) && !isTokenExpired(token));
        } catch (ExpiredJwtException e) {
            System.out.println("JWT token expired: " + e.getMessage());
            return false;
        } catch (Exception e) {
            System.out.println("Invalid JWT token: " + e.getMessage());
            return false;
        }
    }


    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }
}
