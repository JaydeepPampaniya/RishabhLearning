package com.PhoneX.Backend.controller;

import com.PhoneX.Backend.DTO.AddProductDTO;
import com.PhoneX.Backend.DTO.UpdateProductDto;
import com.PhoneX.Backend.Service.ProductService;
import com.PhoneX.Backend.entity.Product;
import com.PhoneX.Backend.globalException.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.io.IOException;

@RestController
@ResponseBody
@RequestMapping("/products")
public class ProductController {

    private final ProductService productService;

    @Autowired
    public ProductController(ProductService productService){
        this.productService=productService;
    }

    @GetMapping("/getProducts")
    public ResponseEntity<Page<Product>> getProducts(@PageableDefault Pageable pageable) {
        return ResponseEntity.ok().body(productService.findAllProducts(pageable));
    }

    @PostMapping("/addProduct")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> addProduct(@RequestPart("addProductDTO") AddProductDTO addProductDTO, @RequestPart("imageFile") MultipartFile imageFile) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(productService.addProduct(addProductDTO, imageFile));
        } catch (IOException e) {
            throw new BadRequestException("Failed to upload the image.");
        }
    }

    @GetMapping("/getProductImage/{id}/image")
    public ResponseEntity<byte[]> getImage(@PathVariable int id) {
        byte[] imageData = productService.getImage(id);
        return ResponseEntity.ok().body(imageData);
    }

    @GetMapping("/{id}/getProduct")
    public ResponseEntity<?> getProduct(@PathVariable int id){
        return ResponseEntity.ok().body(productService.getProduct(id));
    }

    @PatchMapping("/{id}/updateProduct")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> updateProduct(@RequestPart("updateProductDto") UpdateProductDto updateProductDto, @RequestPart(("imageFile")) MultipartFile imageFile){
        try {
            return ResponseEntity.accepted().body(productService.updateProduct(updateProductDto,imageFile));
        } catch (IOException e) {
            throw new BadRequestException("Failed to update a product");
        }
    }

    @DeleteMapping("/{id}/delete")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> deleteProduct(@PathVariable int id){
        return ResponseEntity.accepted().body(productService.deleteProduct(id));
    }
}

